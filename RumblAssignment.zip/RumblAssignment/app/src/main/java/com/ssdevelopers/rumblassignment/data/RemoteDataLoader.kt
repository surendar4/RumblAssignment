package com.ssdevelopers.rumblassignment.data

import android.os.AsyncTask
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.URL
import javax.net.ssl.HttpsURLConnection

/**
 * Created by surendar on 2019-08-03.
 *
 */
class RemoteDataLoader(
    private val resultListener: ResultListener
) : AsyncTask<String, Int, String>() {

    override fun doInBackground(vararg args: String): String {
        val stringUrl = args[0]
        var result = ""

        try {
            val myUrl = URL(stringUrl)
            val connection: HttpsURLConnection = myUrl.openConnection() as HttpsURLConnection
            connection.requestMethod = "GET"
            connection.readTimeout = 15000
            connection.connectTimeout = 15000
            connection.connect()

            //Input Streamer
            val streamReader = InputStreamReader(connection.inputStream)
            val response = BufferedReader(streamReader)
            val stringBuilder = StringBuilder()

            for (inputLine in response.readLine()) {
                stringBuilder.append(inputLine)
            }

            response.close()
            streamReader.close()
            //Set our result equal to our stringBuilder
            result = stringBuilder.toString()

        } catch (e: Exception) {
            e.printStackTrace()
        }
        return result
    }

    override fun onPostExecute(result: String) {
        super.onPostExecute(result)

        if (result.isNotBlank()) {
            resultListener.onSuccess(result)
        } else {
            resultListener.onFailed()
        }
    }

    interface ResultListener {
        fun onSuccess(result: String)
        fun onFailed()
    }
}