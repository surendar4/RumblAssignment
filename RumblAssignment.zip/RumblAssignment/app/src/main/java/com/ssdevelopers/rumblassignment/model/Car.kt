package com.ssdevelopers.rumblassignment.model

/**
 * Created by surendar on 2019-08-03.
 *
 */
data class Car(
    val name: String,
    val photo: String
) : ListItem()