package com.ssdevelopers.rumblassignment.view.viewholders

import android.support.v7.widget.RecyclerView
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import com.ssdevelopers.rumblassignment.R
import com.ssdevelopers.rumblassignment.common.ImageLoader
import com.ssdevelopers.rumblassignment.model.Car
import com.ssdevelopers.rumblassignment.model.Celebrity
import com.ssdevelopers.rumblassignment.model.ListItem

/**
 * Created by surendar on 2019-08-03.
 *
 */
class NormalItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    private val tvTitle: TextView = itemView.findViewById(R.id.tv_title)
    private val ivPhoto: ImageView = itemView.findViewById(R.id.iv_photo)
    private val pbProgress: ProgressBar = itemView.findViewById(R.id.pb_loading)

    lateinit var listener: (Int) -> Unit

    init {
        itemView.setOnClickListener {
            listener.invoke(adapterPosition)
        }
    }

    fun bind(listItem: ListItem) {
        when (listItem) {
            is Celebrity -> bindCelebrity(listItem)
            is Car -> bindCar(listItem)
        }
    }

    private fun bindCelebrity(celebrity: Celebrity) {
        tvTitle.text = celebrity.name
        loadImage(celebrity.photo)
    }

    private fun bindCar(car: Car) {
        tvTitle.text = car.name
        loadImage(car.photo)
    }

    private fun loadImage(url: String) {
        ImageLoader.loadImage(itemView.context, ivPhoto, pbProgress, url)
    }
}