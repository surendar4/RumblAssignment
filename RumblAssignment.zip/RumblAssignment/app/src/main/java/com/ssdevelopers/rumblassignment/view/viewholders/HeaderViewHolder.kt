package com.ssdevelopers.rumblassignment.view.viewholders

import android.support.v7.widget.RecyclerView
import android.view.View
import android.widget.TextView
import com.ssdevelopers.rumblassignment.R
import com.ssdevelopers.rumblassignment.model.Header

/**
 * Created by surendar on 2019-08-03.
 *
 */
class HeaderViewHolder (itemView: View) : RecyclerView.ViewHolder(itemView) {
    private val tvHeader: TextView = itemView.findViewById(R.id.tv_header)

    fun bind(header: Header) {
        tvHeader.text = header.header
    }
}