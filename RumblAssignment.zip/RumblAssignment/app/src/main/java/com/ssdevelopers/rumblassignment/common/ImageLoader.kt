package com.ssdevelopers.rumblassignment.common

import android.content.Context
import android.graphics.drawable.Drawable
import android.widget.ImageView
import android.widget.ProgressBar
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.ssdevelopers.rumblassignment.R

/**
 * Created by surendar on 2019-08-03.
 *
 */
object ImageLoader {

    fun loadImage(context: Context, imageView: ImageView, pbProgress: ProgressBar, imageUrl: String) {
        Glide.with(context)
            .load(imageUrl)
            .error(R.drawable.ic_image_thumb)
            .addListener(object : RequestListener<Drawable> {
                override fun onResourceReady(
                    resource: Drawable?, model: Any?, target: Target<Drawable>?,
                    dataSource: DataSource?, isFirstResource: Boolean
                ): Boolean {
                    pbProgress.gone()
                    return false
                }

                override fun onLoadFailed(
                    e: GlideException?, model: Any?, target: Target<Drawable>?,
                    isFirstResource: Boolean
                ): Boolean {
                    pbProgress.gone()
                    return false
                }
            })
            .transition(DrawableTransitionOptions.withCrossFade())
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .into(imageView)
    }
}