package com.ssdevelopers.rumblassignment.view

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentActivity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import com.ssdevelopers.rumblassignment.R
import com.ssdevelopers.rumblassignment.common.DebugUtil
import com.ssdevelopers.rumblassignment.common.ImageLoader
import com.ssdevelopers.rumblassignment.model.Car
import com.ssdevelopers.rumblassignment.model.Celebrity
import com.ssdevelopers.rumblassignment.model.ListItem

/**
 * Created by surendar on 2019-08-03.
 *
 */
class FullImageViewFragment : Fragment() {

    private lateinit var rootLayout: ViewGroup
    private lateinit var fragmentActivity: FragmentActivity
    private lateinit var ivFullImage: ImageView
    private lateinit var pbProgress: ProgressBar

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_full_image_view, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initReferences(view)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        fragmentActivity = requireActivity()
        showOrHideNavigationIcon(true)

        val listItem: ListItem? = arguments?.getParcelable(KEY_LIST_ITEM) as ListItem?
        showFullImage(listItem)
    }

    override fun onDestroy() {
        super.onDestroy()

        showOrHideNavigationIcon(false)
    }

    private fun initReferences(view: View) {
        rootLayout = view.findViewById(R.id.root_Layout)
        ivFullImage = view.findViewById(R.id.iv_full_image)
        pbProgress = view.findViewById(R.id.pb_loading)

        rootLayout.setOnClickListener { }
    }

    private fun showFullImage(listItem: ListItem?) {
        when (listItem) {
            is Celebrity -> loadImage(listItem.photo)
            is Car -> loadImage(listItem.photo)
            else -> {
                DebugUtil.throwRuntimeException(RuntimeException("InvalidListItem"))
                requireActivity().supportFragmentManager.popBackStack()
            }
        }
    }

    private fun loadImage(downloadUrl: String) {
        ImageLoader.loadImage(requireContext(), ivFullImage, pbProgress, downloadUrl)
    }

    private fun showOrHideNavigationIcon(show: Boolean) {
        (fragmentActivity as MainActivity).apply {
            supportActionBar?.setDisplayHomeAsUpEnabled(show)
            supportActionBar?.setHomeButtonEnabled(show)
        }
    }

    companion object {
        private const val KEY_LIST_ITEM = "i"

        fun newInstance(listItem: ListItem): FullImageViewFragment {
            val fragment = FullImageViewFragment()
            val bundle = Bundle()
            bundle.putParcelable(KEY_LIST_ITEM, listItem)
            fragment.arguments = bundle
            return fragment
        }
    }
}