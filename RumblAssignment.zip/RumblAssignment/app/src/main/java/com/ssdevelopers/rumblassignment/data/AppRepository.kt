package com.ssdevelopers.rumblassignment.data

import android.content.Context
import android.content.SharedPreferences
import android.net.ConnectivityManager
import com.ssdevelopers.rumblassignment.model.Car
import com.ssdevelopers.rumblassignment.model.Celebrity

/**
 * Created by surendar on 2019-08-03.
 *
 */
object AppRepository {
    private const val itemListUrl = "https://api.myjson.com/bins/1gaa29"

    private const val KEY_PREF_KEY = "rumbl_assg_repo"
    private const val KEY_RESULT = "result"
    private lateinit var sharePref: SharedPreferences

    fun loadItemsList(context: Context, getItemsListListener: GetItemsListListener) {
        sharePref = context.getSharedPreferences(KEY_PREF_KEY, Context.MODE_PRIVATE)

        val result = getResultFromSharedPref()
        if (result.isNotBlank()) {
            val parser = GetItemsParser(result)
            parser.parse(getItemsListListener)

            if (isNetworkAvailable(context)) {
                loadDataFromRemote(getItemsListListener)
            }
        } else {
            loadDataFromRemote(getItemsListListener)
        }
    }

    private fun loadDataFromRemote(getItemsListListener: GetItemsListListener) {
        RemoteDataLoader(object : RemoteDataLoader.ResultListener {
            override fun onSuccess(result: String) {
                val resultFromSharedPref = getResultFromSharedPref()

                //Update only if different results were there
                if (resultFromSharedPref.isBlank() || (resultFromSharedPref != result)) {
                    saveResultInSharedPref(result)

                    val parser = GetItemsParser(result)
                    parser.parse(getItemsListListener)
                }
            }

            override fun onFailed() {
                getItemsListListener.onError()
            }
        }).execute(itemListUrl)
    }

    private fun getResultFromSharedPref(): String {
        return sharePref.getString(KEY_RESULT, "") ?: ""
    }

    private fun saveResultInSharedPref(result: String) {
        sharePref.edit().putString(KEY_RESULT, result).apply()
    }

    private fun isNetworkAvailable(context: Context): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager?
        return connectivityManager?.activeNetworkInfo?.isConnected ?: false
    }

    interface GetItemsListListener {
        fun onItemListLoaded(celebritiesList: List<Celebrity>, carsList: List<Car>)
        fun onError()
    }
}