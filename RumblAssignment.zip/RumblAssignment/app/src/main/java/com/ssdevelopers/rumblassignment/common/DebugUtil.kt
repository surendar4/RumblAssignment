package com.ssdevelopers.rumblassignment.common

import com.ssdevelopers.rumblassignment.BuildConfig

/**
 * Created by surendar on 2019-08-03.
 *
 */
object DebugUtil {

    private val isDebug: Boolean by lazy { BuildConfig.DEBUG }

    fun throwRuntimeException(exception: RuntimeException) {
        if (isDebug) {
            throw exception
        }
    }
}