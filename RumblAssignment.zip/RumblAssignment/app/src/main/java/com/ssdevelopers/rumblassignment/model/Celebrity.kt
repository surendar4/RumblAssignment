package com.ssdevelopers.rumblassignment.model

/**
 * Created by surendar on 2019-08-03.
 *
 */
data class Celebrity(
    val name: String,
    val age: Int,
    val height: Int,
    val popularity: Int,
    val photo: String
) : ListItem()