package com.ssdevelopers.rumblassignment.data

import com.ssdevelopers.rumblassignment.model.Car
import com.ssdevelopers.rumblassignment.model.Celebrity
import org.json.JSONObject

/**
 * Created by surendar on 2019-08-03.
 *
 */
class GetItemsParser(private val result: String) {

    fun parse(resultListener: AppRepository.GetItemsListListener) {

        try {
            if (result.isNotBlank()) {
                val keyCelebrities = "celebrities"
                val keyCars = "cars"

                val keyAge = "age"
                val keyHeight = "height"
                val keyPopularity = "popularity"
                val keyPhoto = "photo"

                val celebritiesList = mutableListOf<Celebrity>()
                val carsList = mutableListOf<Car>()

                val rootJson = JSONObject(result)
                val celebritiesJson = rootJson.getJSONObject(keyCelebrities)
                val carsJson = rootJson.getJSONObject(keyCars)

                for (celebrity in celebritiesJson.keys()) {
                    val celebrityJson = celebritiesJson.getJSONObject(celebrity)

                    val age = celebrityJson.getInt(keyAge)
                    val height = celebrityJson.getInt(keyHeight)
                    val popularity = celebrityJson.getInt(keyPopularity)
                    val photo = celebrityJson.getString(keyPhoto)

                    celebritiesList.add(Celebrity(celebrity, age, height, popularity, photo))
                }

                for (car in carsJson.keys()) {
                    val carJson = carsJson.getJSONObject(car)
                    val photo = carJson.getString(keyPhoto)

                    carsList.add(Car(car, photo))
                }

                resultListener.onItemListLoaded(celebritiesList, carsList)
            } else {
                resultListener.onError()
            }
        } catch (e: Exception) {
            resultListener.onError()
        }
    }
}