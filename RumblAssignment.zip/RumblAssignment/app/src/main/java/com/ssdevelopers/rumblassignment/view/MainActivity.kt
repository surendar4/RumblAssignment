package com.ssdevelopers.rumblassignment.view

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.MenuItem
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import com.ssdevelopers.rumblassignment.R
import com.ssdevelopers.rumblassignment.common.gone
import com.ssdevelopers.rumblassignment.common.visible
import com.ssdevelopers.rumblassignment.data.AppRepository
import com.ssdevelopers.rumblassignment.model.Car
import com.ssdevelopers.rumblassignment.model.Celebrity
import com.ssdevelopers.rumblassignment.model.Header
import com.ssdevelopers.rumblassignment.model.ListItem

class MainActivity : AppCompatActivity() {

    private lateinit var rvItems: RecyclerView
    private lateinit var pbLoading: ProgressBar
    private lateinit var tvError: TextView
    private lateinit var flFragmentContainer: FrameLayout

    private lateinit var adapter: RecyclerViewAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initReferences()
        initRecyclerView()
        startLoading()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            super.onBackPressed()
        }
        return super.onOptionsItemSelected(item)
    }

    private fun initReferences() {
        rvItems = findViewById(R.id.rv_items)
        pbLoading = findViewById(R.id.pb_loading)
        tvError = findViewById(R.id.tv_error)
        flFragmentContainer = findViewById(R.id.fl_fragment_container)
    }

    private fun initRecyclerView() {
        adapter = RecyclerViewAdapter { clickedItem ->
            showFullImage(clickedItem)
        }

        val manager = GridLayoutManager(this, getSpanCountForGridLayout())
        manager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                return if (adapter.getItemViewType(position) == RecyclerViewAdapter.VIEW_TYPE_HEADER) {
                    manager.spanCount
                } else {
                    1
                }
            }
        }

        rvItems.layoutManager = manager
        rvItems.adapter = adapter
    }

    private fun getSpanCountForGridLayout(): Int {
        val screenWidthInDp = resources.configuration.screenWidthDp
        val cellWidthInDp = 140
        return screenWidthInDp / cellWidthInDp
    }

    private fun startLoading() {
        AppRepository.loadItemsList(this, object : AppRepository.GetItemsListListener {
            override fun onItemListLoaded(celebritiesList: List<Celebrity>, carsList: List<Car>) {
                val itemsList: MutableList<ListItem> = mutableListOf()

                if (celebritiesList.isNotEmpty()) {
                    itemsList.add(Header("Celebrities"))
                    itemsList.addAll(celebritiesList)
                }

                if (carsList.isNotEmpty()) {
                    itemsList.add(Header("Cars"))
                    itemsList.addAll(carsList)
                }
                showItems(itemsList)
            }

            override fun onError() {
                showError()
            }
        })
    }

    private fun showItems(itemsList: List<ListItem>) {
        pbLoading.gone()
        tvError.gone()
        rvItems.visible()

        adapter.swapItems(itemsList)
    }

    private fun showError() {
        pbLoading.gone()
        rvItems.gone()
        tvError.visible()
    }

    private fun showFullImage(item: ListItem) {
        val tag = "FullImageFragment"
        val fragment = FullImageViewFragment.newInstance(item)
        val transaction = supportFragmentManager.beginTransaction()
        transaction.add(R.id.fl_fragment_container, fragment, tag)
        transaction.addToBackStack(tag)
        transaction.commit()
    }
}
