package com.ssdevelopers.rumblassignment.common

import android.view.View

/**
 * Created by surendar on 2019-08-03.
 *
 */
fun View.gone() {
    visibility = View.GONE
}

fun View.visible() {
    visibility = View.VISIBLE
}