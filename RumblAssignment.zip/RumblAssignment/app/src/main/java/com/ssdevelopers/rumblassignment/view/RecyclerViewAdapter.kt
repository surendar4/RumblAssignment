package com.ssdevelopers.rumblassignment.view

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import com.ssdevelopers.rumblassignment.R
import com.ssdevelopers.rumblassignment.common.DebugUtil
import com.ssdevelopers.rumblassignment.model.Car
import com.ssdevelopers.rumblassignment.model.Celebrity
import com.ssdevelopers.rumblassignment.model.Header
import com.ssdevelopers.rumblassignment.model.ListItem
import com.ssdevelopers.rumblassignment.view.viewholders.HeaderViewHolder
import com.ssdevelopers.rumblassignment.view.viewholders.NormalItemViewHolder

/**
 * Created by surendar on 2019-08-03.
 *
 */
class RecyclerViewAdapter(private val itemClickListener: (ListItem) -> Unit) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var itemsList: List<ListItem> = emptyList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            VIEW_TYPE_HEADER -> {
                val itemView = LayoutInflater.from(parent.context).inflate(R.layout.view_header_item, parent, false)
                HeaderViewHolder(itemView)
            }

            VIEW_TYPE_NORMAL_ITEM -> {
                val itemView = LayoutInflater.from(parent.context).inflate(R.layout.view_normal_item, parent, false)
                val viewHolder = NormalItemViewHolder(itemView)
                viewHolder.listener = { adapterPosition ->
                    itemClickListener.invoke(itemsList[adapterPosition])
                }
                viewHolder
            }

            else -> throw RuntimeException("Invalid view type")
        }
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        when (viewHolder) {
            is HeaderViewHolder -> viewHolder.bind(itemsList[position] as Header)
            is NormalItemViewHolder -> viewHolder.bind(itemsList[position])
            else -> DebugUtil.throwRuntimeException(RuntimeException("Invalid viewHolder"))
        }
    }

    override fun getItemViewType(position: Int): Int {
        return when (itemsList.get(position)) {
            is Header -> VIEW_TYPE_HEADER
            is Celebrity, is Car -> VIEW_TYPE_NORMAL_ITEM
            else -> throw RuntimeException("Invalid Item @getViewItemType")
        }
    }

    override fun getItemCount(): Int = itemsList.size

    fun swapItems(items: List<ListItem>) {
        itemsList = items
        notifyDataSetChanged()
    }

    companion object {
        const val VIEW_TYPE_HEADER = 0
        const val VIEW_TYPE_NORMAL_ITEM = 1
    }
}